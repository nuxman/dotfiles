class Foo
  include Bar
end
